# If you run this file as the main file it will fit an encoder on saved data
# -- configuration --

FIT_DATA_LOAD_PATH = "./data/hand_data_features_as_np_array.npy"
ENCODER_SAVE_PATH = "./data/pca_encoder.pkl"
# -- end configuration  --

import numpy as np
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import pdb

from util import store_object

BUZZ_MOTOR_COUNT = 4
BUZZ_MAX_VIBRATION_QUANTIZATION = 255 # look at that fancy word. it just means it has 255 distinct levels of vibration

def fit_encoder(data):
    return PCA(n_components=BUZZ_MOTOR_COUNT).fit(data.reshape(data.shape[0],-1))

def encode_pca_data(encoder, data, scale=True, reshape=True, to_list=False, to_int=True): # TODO it's an odd design that encode_data isn't bundled with the encoder object. consider switching to a wrapper class and pickling that instance
    if(data is None):
        return None
    if (reshape):
        data = data.reshape(data.shape[0],-1) # smush the non-index dimensions together into a single vector for PCA      
    data = encoder.transform(data)
    if (scale):
        data = scale_data(data)
    data = data.squeeze()
    if (to_int):
        data = data.astype('uint16')
    if (to_list):
        data = data.tolist()
    return data

def scale_data(data):
    # scale the data between 0 and 255.0 to fit inside what buzz can model
    data = np.interp(data, (data.min(), data.max()), (0, BUZZ_MAX_VIBRATION_QUANTIZATION))
    return data


if __name__ == "__main__":
    data = np.load(FIT_DATA_LOAD_PATH)
    encoder = fit_encoder(data)
    store_object(encoder, ENCODER_SAVE_PATH)

    pdb.set_trace()
    data = encode_pca_data(encoder, data, scale=False)

    plt.plot(data)
    plt.title("PCA encoded vibration levels of all data before scaling to Buzz range")
    plt.show()

    data = scale_data(data)
    plt.plot(data)
    plt.title("PCA encoded vibration after scaling between 0 and 255")
    plt.show()