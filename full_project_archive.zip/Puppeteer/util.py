import pickle
import time

def store_object(obj, filename):
    with open(filename, 'wb') as output: # overwrites any existing file
        pickle.dump(obj, output, pickle.HIGHEST_PROTOCOL)

def load_object(filename):
    with open(filename, 'rb') as input:
        return pickle.load(input)

current_milli_time = lambda: int(round(time.time() * 1000))