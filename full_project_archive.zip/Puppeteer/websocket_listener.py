# The main executable file for testing hand tracking and recording hand tracking data
# See configuration section below to switch modes and alter settings

import asyncio
import websockets
import json
import time
import pdb
import numpy as np

from util import load_object, current_milli_time
from extract_features_and_save import extract_features, save_features_as_array, save_json_dump, clear_existing_data, rehydrate_hands_from_pca_encoding
from pca_encoder import encode_pca_data, fit_encoder
from vibration_station import initialize_buzz

RECORD_MODE = "record_mode"
TEST_MODE = "test_mode"
# available encoders:
PCA_ENCODER = "pca_encoder"
AUTOENCODER = "autoencoder"


# -- configuration --

# general settings
mode = RECORD_MODE # SET THIS TO TEST_MODE if you want to evaluate. set to RECORD_MODE if you want to save new data for fitting an encoder

# record_mode settings
num_frames_to_record = 20000
save_rehydrated = False # whether or not to save the encoded -> decoded json blob too. useful for measuring error that encoder injects

# test_mode settings
pca_encoder_path = './data/pca_encoder.pkl'
autoencoder_path = None # TODO
encoder = PCA_ENCODER # switch between encoders for TEST_MODE
PASSTHROUGH_SERVER_PORT = 6777 # if you listen to the ultraleap websocket directly it won't be in-sync with the encoded version
ENCODER_SERVER_PORT = 6778
log_latencies = False
# -- end configuration -- 

last_milli_time = None
processing_frame_now = False

encoder_path = pca_encoder_path if encoder == PCA_ENCODER else autoencoder_path
if (mode == TEST_MODE):
    print("Starting test mode...")
    try:
        encoder = load_object(encoder_path)
    except:
        print("Unable to find pre-fitted encoder file: '" + encoder_path + "' exiting.")    
        exit()
    encoding_function = encode_pca_data if encoder == PCA_ENCODER else None # TODO chage None to autocoder_encode_data when it exists. also it's weird that this function is not encapsulated within the encoder. see pca_encoder.py for refactor idea
elif (mode == RECORD_MODE):
    clear_existing_data()
    print("Starting record mode in...")
    for i in np.flip((np.arange(5) + 1)):
        print(i)
        time.sleep(1)

    print("Recording " + str(num_frames_to_record) + " frames...")
else:
    print("Unrecognized mode: '" + mode + "' exiting.")
    exit()
data = []
save_data = True

# these 2 websockets run in parallel and remain concurrent. you get two streams of data: 1 unmodified and 1 encoded then unencoded (but transformed back to the original JSON shape)
# this consumes the data, then encodes the frame, then transforms the data back to look like the original data

# these servers don't do anything with the messages they receive from the clients
# async def encoder_server_handler(websocket, path) -> None:
#     while True:
#         message = await websocket.recv()   
#         print("Server received message: " + str(message))


# async def passthrough_server_handler(websocket, path) -> None:
#     while True:
#         message = await websocket.recv()
#         print("Server received message: " + str(message))


async def main_loop(loop):
    # encoder_server = await websockets.serve(encoder_server_handler, "localhost", ENCODER_SERVER_PORT)
    # passthrough_server = await websockets.serve(passthrough_server_handler, "localhost", PASSTHROUGH_SERVER_PORT)
    global last_milli_time
    listener_host = "localhost"
    listener_port = "6437"
    listener_path = "/v6.json"
    listener_websocket_resource_url = f"ws://{listener_host}:{listener_port}{listener_path}"

    frameCount = 0

    async with websockets.connect(listener_websocket_resource_url) as websocket:
        last_milli_time = current_milli_time()
        send_vibration_frame_left, left_adddress = await initialize_buzz(buzzLabel="Left hand")
        # send_vibration_frame_right, right_address = await initialize_buzz([left_adddress], buzzLabel="Right hand")
        # should_reverse = await test_setup_if_should_reverse(send_vibration_frame_left, send_vibration_frame_right)

        # if (should_reverse): # just swap references
        #     temp = send_vibration_frame_left
        #     send_vibration_frame_left = send_vibration_frame_right
        #     send_vibration_frame_left = temp
        #     temp = None
        #     temp = left_adddress
        #     left_adddress = right_address
        #     right_address = temp
        #     temp = None
        async for message in websocket:
            if (mode == RECORD_MODE):
                record_hand_tracking_data(message)
            elif (mode == TEST_MODE):
                current_time = current_milli_time()
                if (current_time - last_milli_time > 150):
                    frameCount += 1
                    if(log_latencies):
                        time_start =  current_milli_time()
                        time_since_last_frame = current_milli_time() - last_milli_time
                        print("t1 " + str(time_since_last_frame) + " time since last frame")    

                    encoded_frame_left, encoded_frame_right = await test_hand_tracking_data(message, encoder, use_both_hands=True)

                    if(log_latencies):
                        time_to_encode = current_milli_time() - time_start
                        print("t2 " + str(time_to_encode) + " time to encode")                    
                    print("Waiting on frames: " + str(encoded_frame_left) + ", " + str(encoded_frame_right))
                    # await send_vibration_frame_left(encoded_frame)
                    await send_vibration_frame_left(encoded_frame_left, frameCount)
                    # await send_vibration_frame_right(encoded_frame_right, frameCount)
                    if(log_latencies):
                        time_for_whatever = current_milli_time() - time_to_encode - time_start
                        print("t3 " + str(time_for_whatever) + " time for whatever")       

                    if(log_latencies):
                        time_for_buzz_vibrations = current_milli_time() - time_for_whatever - time_to_encode - time_start
                        print("t4 " + str(time_for_buzz_vibrations) + " time for buzz vibrations")     

                    if(log_latencies):
                        total_time_to_complete = time_for_buzz_vibrations + time_for_whatever + time_to_encode
                        print("t5 " + str(total_time_to_complete) + " total time to complete")    
                    last_milli_time = current_time

# # this one consumes the original data and waits for the encoder to finish before emitting the original data on a different port

async def test_setup_if_should_reverse(buzz_left, buzz_right):
    print("This is left")
    await buzz_left([255,255,255,255])
    time.sleep(1)
    await buzz_left([0,0,0,0])
    print("This is right")
    await buzz_right([255,255,255,255])
    time.sleep(1)
    await buzz_right([0,0,0,0])
    value = input("Press 'r' to reverse or any other key to keep the left/right assignment.\n")
    if (value == 'r'):
        return True
    else:
        return False

# this third websocket listens to the local ultraleap websocket and passes the data to the two servers
# async def listener_websocket(hostname: str, port: str, path: str) -> None:
#     websocket_resource_url = f"ws://{hostname}:{port}{path}"
#     async with websockets.connect(websocket_resource_url) as websocket:
#         original_frame, encoded_frame = await listener_handler(websocket)
#         return (original_frame, encoded_frame)


# Used to process incoming hand tracking json messages from the local ultraleap websocket
def record_hand_tracking_data(message:str):
    global save_data
    done_msg = " (not saving these frames anymore)" if (len(data) > num_frames_to_record) else ""

    if(message_contains_hand_and_finger_data(message)):
        data.append(message)
        print("Received frame " + str(len(data)) + done_msg)
    else:
        print("Skipping empty or partially empty frame")

    if (len(data) >= num_frames_to_record): 
        features_arr = extract_features(data, reshape=True)
        if (save_rehydrated):
            fit_pca_encoder = fit_encoder(features_arr)
            encoded_frame_data = encode_pca_data(fit_pca_encoder, features_arr)
            rehydrated_json_dump = rehydrate_hands_from_pca_encoding(fit_pca_encoder, encoded_frame_data, data)
            save_json_dump(rehydrated_json_dump, "./data/rehydrated_hand_data_dump.json")
        save_features_as_array(features_arr)
        save_json_dump(data)
        save_data = False # only save once

async def test_hand_tracking_data(message, encoder, use_both_hands = False):
    def get_empty_frame_if_none(encoded_frame):
        if (encoded_frame is None):
            return [0,0,0,0] # when skipping frames with bad hand data, stop vibrating
        else:
            return encoded_frame

    if(message_contains_hand_and_finger_data(message)):
        # try:
        if(not(use_both_hands)):
            frame_data_left = extract_features(message)
            frame_data_left = encode_pca_data(encoder, frame_data_left, to_list=True) # TODO switch to a general encoding function. not pca specific
            frame_data_left = get_empty_frame_if_none(frame_data_left)
            return (frame_data_left, frame_data_left)
        else:
            frame_data_left = extract_features(message)
            frame_data_right = extract_features(message, hand_type="right")
            frame_data_left = encode_pca_data(encoder, frame_data_left, to_list=True) 
            frame_data_right = encode_pca_data(encoder, frame_data_right, to_list=True) # TODO encode left and right hands with different encoders
            frame_data_left = get_empty_frame_if_none(frame_data_left)
            frame_data_right = get_empty_frame_if_none(frame_data_right)
            return (frame_data_left, frame_data_right)
        # except:
        #     print("Dropping frame. Failed to encode data")
    else:
        # print("Skipping empty or partially empty frame")
        return ([0,0,0,0],[0,0,0,0])    
    
def message_contains_hand_and_finger_data(message):
    if (message.find("hands\":[]") < 0): # make sure there are hands in frame and the ultraleap is ready and sending data (it only sends some status messages while it first turns on)
        entry = json.loads(message) # TODO this is slow for little reason. find a better "data not ready yet" detector
        if ("hands" in entry and len(entry["hands"]) > 0):
            if("pointables" in entry and len(entry["pointables"]) > 0):
                return True
    return False

if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    loop.run_until_complete(asyncio.wait([main_loop(loop)]))
    loop.run_forever()