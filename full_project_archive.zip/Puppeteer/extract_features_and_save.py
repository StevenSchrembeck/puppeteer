# A sub-module used to pull specific data out of the ultraleap JSON messages and save or clear that data

import os
import json
import pdb
import numpy as np

# -- configuration --
feature_array_save_path = "./data/hand_data_features_as_np_array"
json_dump_save_path = "./data/hand_data_dump.json"
# -- end configuration --


def extract_features(data_list, reshape=False, hand_type="left"):  # pull out only the data we want
    hand_properties = ["palmNormal", "palmPosition", "wrist"]
    finger_properties = ["tipPosition"]
    number_of_human_fingers_per_hand = 5  # hey, you never know

    if type(data_list) is str:  # force conversion to a list for a single frame
        data_list = [data_list]
    data_as_arrays = np.zeros(
        (len(data_list), 8, 3)
    )  # the second position could be dynamic based on num of properties, but who cares?

    for index, frame in enumerate(data_list):
        json_frame = json.loads(frame)
        hands = json_frame.get("hands")
        if(hands[0].get("type") == hand_type):
            hand = hands[0]
        elif(len(hands) > 1 and (hands[1].get("type") == hand_type)):
            hand = hands[1]
        else:
            return None
        hand_id = hand.get("id")
        hand_data = np.array([hand.get(prop) for prop in hand_properties])

        if hand_data.shape[1] != 3 and hand_data.shape[0] != len(
            hand_properties
        ):  # expects each property value is a length 3 vector and that the number of properties match
            1 / 0  # boom

        data_as_arrays[index][0 : len(hand_data)] = hand_data

        for finger_index, finger in enumerate(json_frame.get("pointables")):
            if (
                finger.get("handId") == hand_id
            ):  # don't include any data from a second hand, yet
                finger_data = np.array([finger.get(prop) for prop in finger_properties])

                if finger_data.shape[1] != 3 and finger_data.shape[0] != len(
                    finger_properties
                ):
                    1 / 0  # boom

                finger_data_start_index = len(hand_data) + finger_index
                finger_data_end_index = len(hand_data) + finger_index + len(finger_data)
                data_as_arrays[index][
                    finger_data_start_index:finger_data_end_index
                ] = finger_data  # looks complicated, but i'm just inserting some arrays with configurable size based on the length of finger_properties

    # pdb.set_trace()
    # sample data (assuming there are 8 total properties. originally 3 for a hand and 1 for each finger)
    # data_as_arrays[index]
    # array([[   0.237143,   -0.946325,   -0.21962 ],
    #        [ -82.490501,  202.77829 ,   26.042208],
    #        [ -82.362137,  189.479279,   95.077568],
    #        [ -15.075111,  178.282196,   -9.779669], # finger data starts on this row
    #        [ -55.99604 ,  211.92009 ,  -68.624962],
    #        [ -88.151657,  201.456131,  -77.498871],
    #        [-111.65979 ,  186.951691,  -65.425003],
    #        [-129.974991,  175.578094,  -39.394772]])

    if reshape == True:
        data_as_arrays = data_as_arrays.reshape(len(data_list), -1)  # reshape from separated features like (1000, 8, 3) to a list of 1d vectors like (1000, 24). less readable but neccessary for most encoders

    return data_as_arrays


# Note this function is not well-optimized. Isn't meant for real-time work and it isn't flexible (it'll break if you change which properties you record from these hand_properties = ["palmNormal", "palmPosition", "wrist"] finger_properties = ["tipPosition"])

# Note this function is not well-optimized. Isn't meant for real-time work and it isn't flexible (it'll break if you change which properties you record from these hand_properties = ["palmNormal", "palmPosition", "wrist"] finger_properties = ["tipPosition"])
def rehydrate_hands_from_pca_encoding(encoder, encoded_frames, json_frames_to_overwrite):
    copied_list = list(json_frames_to_overwrite)

    for data_index, json_frame_to_overwrite in enumerate(copied_list):
        encoded_frame = encoded_frames[data_index]
        full_frame = encoder.inverse_transform(encoded_frame).reshape(8,3)
        assert full_frame.shape == (8, 3)  # break if you change the properties recorded

        # hand_properties = ["palmNormal", "palmPosition", "wrist"]
        # finger_properties = ["tipPosition"]

        json_frame = json.loads(json_frame_to_overwrite) # deep copy to avoid mutating the original

        # it's bad i don't care! (much)
        hand = json_frame.get("hands")[0]
        hand["palmNormal"] = full_frame[0].tolist()
        hand["palmPosition"] = full_frame[1].tolist()
        hand["wrist"] = full_frame[2].tolist()
        fingers = json_frame.get("pointables")

        fingers[0]["tipPosition"] = full_frame[3].tolist()
        fingers[1]["tipPosition"] = full_frame[4].tolist()
        fingers[2]["tipPosition"] = full_frame[5].tolist()
        fingers[3]["tipPosition"] = full_frame[6].tolist()
        fingers[4]["tipPosition"] = full_frame[7].tolist()

        copied_list[data_index] = str(json_frame).replace("'", '"').replace("True", "true") # back to a string because i dont feel like rewriting the json save function
    return copied_list

def save_features_as_array(feature_array):
    np.save(feature_array_save_path, feature_array)  # reload with np.load


def save_json_dump(data: list, filepath=json_dump_save_path):  # input a list of json formatted strings
    data_as_json_string = (
        "[" + ",".join(data) + "]"
    )  # "[" + ",".join(["a","b","c"]) + "]" --> '[a,b,c]'
    file_to_save = open(
        filepath, "w"
    )  # this is a full dump of all the JSON messages received with hand data up until this point (not just the requested features like in the .npy file)
    file_to_save.write(data_as_json_string)
    file_to_save.close()


def clear_existing_data():
    print("Deleting old hand tracking data...")
    if os.path.exists(feature_array_save_path + ".npy"):
        os.remove(feature_array_save_path + ".npy")  # remove any pre-existing files
    if os.path.exists(json_dump_save_path):
        os.remove(json_dump_save_path)  # remove any pre-existing files
