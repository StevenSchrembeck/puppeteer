import asyncio
from bleak import BleakClient
from bleak import discover
from neosensory_python import NeoDevice
import pdb

from util import current_milli_time

lastFrameCount = 0

def notification_handler(sender, data):
    print("{0}: {1}".format(sender, data))

async def initialize_buzz(blacklist_addresses = None, buzzLabel = ""):
    print("Initialing Buzz: " + buzzLabel)
    buzz_addr = "not yet set"  # e.g. "EB:CA:85:38:19:1D"
    devices = await discover()
    for d in devices:
        if str(d).find("Buzz") > 0:
            print("    Found a Buzz! " + str(d) +
             "\r\nAddress substring: " + str(d)[:17])
            # set the address to a found Buzz
            if(blacklist_addresses is None): # register the first buzz you find if there's no blacklisted addresses
                buzz_addr = str(d)[:17]
                break
            elif(not(str(d)[:17] in blacklist_addresses)): # otherwise the first one you find not in the blacklist
                buzz_addr = str(d)[:17]
                break
            else:
                print("    Ignoring already registered Buzz: " + str(d)[:17])

    if(buzz_addr == "not yet set"):
        print("No buzzes found. Dividing by zero. Get ready to explode")
        1 / 0

    client = BleakClient(buzz_addr)
    try:
        await client.connect()

        my_buzz = NeoDevice(client)

        await asyncio.sleep(1)

        x = await client.is_connected()
        print("    Connection State: {0}\r\n".format(x))

        def notification_handler_wrapper(sender, data):
            global lastFrameCount
            notification_handler(sender, (str(lastFrameCount) + "    Buzz " + buzzLabel + " says: " + str(data)))

        await my_buzz.enable_notifications(notification_handler_wrapper)

        await asyncio.sleep(1)

        await my_buzz.request_developer_authorization()

        await my_buzz.accept_developer_api_terms()

        await my_buzz.pause_device_algorithm()

        await my_buzz.clear_motor_queue()

        async def send_vibration_frame(motor_vibrate_frame, frameCount=0):
            global lastFrameCount
            lastFrameCount = frameCount
            try:
                await my_buzz.vibrate_motors(motor_vibrate_frame)                
            except KeyboardInterrupt:
                await my_buzz.resume_device_algorithm()
                exit()

        return send_vibration_frame, buzz_addr
    except Exception as e:
        print(e)
        client.disconnect()
        exit()